package JavaApplication;
import  java.util.Scanner;


public class checkEmailAndPassword {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        boolean validEmail = false;
        do{
            System.out.println("Please enter your valid email?");
            String email = scan.next();
            boolean hasValidAt = !(email.indexOf("@") < 1) && (email.lastIndexOf("@") == email.indexOf("@"));
            boolean hasValidDomain = (email.indexOf("@") < email.lastIndexOf(".")-1) && (email.lastIndexOf(".") < email.length() - 1);
            boolean hasValidCharOnly = false;
            String inValidChars = "!#$%^&*()";// on peut ajouter encore.

            int numOfInvalidChar = 0;
            for(int i = 0; i < inValidChars.length(); i++){

                if(email.contains("" + inValidChars.charAt(i))){
                    numOfInvalidChar ++;
                }
                hasValidCharOnly = numOfInvalidChar == 0;
        }
            if(hasValidAt && hasValidDomain && hasValidCharOnly){
                validEmail = true;
                System.out.println("thank you, it's a valid email.\n Please enter your pass word");
            }
        }while (!validEmail);

         scan.nextLine();
         String password = scan.nextLine();

         boolean isPasswordCorrect = false;

         String correctPassword = "1234567890";
         int attemp =0;
         while(!(correctPassword == password)){
             System.out.println("Password is not correct, please enter correct password");
             attemp ++;
             password = scan.nextLine();

             if (attemp > 1){
                 System.out.println("It's 3 times now , please try later");
                 System.exit(0);
             }

         }




    }
}
